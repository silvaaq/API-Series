//requisição do tipo get para retornar os dados da API
async function getSeries() {
    const url = 'http://localhost:8082/series'

    const retorno = await fetch(url, {
        method: "GET",
        headers: {
            "Content-type": "application/json"
        }
    });

    const dados = await retorno.json();

    console.log(dados);

    dados.forEach(series => {
        console.log(series);

        const tr = document.createElement('tr')
        const div = document.createElement('div')

        const listSeries = document.getElementById('listaSeries')

        const tdNomeSerie = document.createElement('td')
        tdNomeSerie.textContent = series.nomeSerie;

        const tdNumTemp = document.createElement('td')
        tdNumTemp.textContent = series.numTemporadas

        const tdAnoLancamento = document.createElement("td")
        tdAnoLancamento.textContent = series.anoLancamento

        const tdProdutora = document.createElement('td')
        tdProdutora.textContent = series.estudio

        const tdEdit = document.createElement('img')
        tdEdit.src = './assets/icons/pencil.svg'

        tdEdit.addEventListener("click", () => {
            alert("Função funcional")

            const id = series.id

            document.getElementById("nomeSerie").value = series.nomeSerie
            document.getElementById("temporadas").value = series.numTemporadas
            document.getElementById("anoLancamento").value = series.anoLancamento
            document.getElementById("produtora").value = series.estudio

            // document.getElementById('btnCadastrar').removeEventListener('click', ataulizarSerie)
            // document.getElementById('btnCadastrar').addEventListener('click', ataulizarSerie)

            document.getElementById("btnCadastrar").textContent = "Atualizar série"

            if (window.confirm("você deseja atualizar a série?")) {

                async function ataulizarSerie() {
                    //tratamento de exceções (api)
                    try {
                        const dadosEnviadosAtualizados = {
                            "nomeSerie": document.getElementById("nomeSerie").value,
                            "temporadas": document.getElementById("temporadas").value,
                            "estudio": document.getElementById("produtora").value,
                            "anoLancamento": document.getElementById("anoLancamento").value
                        }

                        const retorno = fetch(`http://localhost:8082/series/${id}`, {
                            headers: {
                                "Content-type": "application/json"
                            },
                            body: JSON.stringify(dadosEnviadosAtualizados),
                            method: "PUT"
                        })

                        if (retorno.ok) {
                            alert("A série foi atualizada com sucesso!")
                        } else {
                            alert(`Não foi possível atualizar a série ${retorno.status}`)
                        }
                    } catch (error) {
                        console.log(error);
                    }
                }
            }


            document.getElementById('btnCadastrar').removeEventListener('click');
        })

        const tdDelete = document.createElement('img')
        tdDelete.src = './assets/icons/trash.svg'

        tdDelete.addEventListener("click", () => {
            //lógica para deletar
            const id = series.id

            const validarConfirmacaoUsuario = window.confirm("Você deseja realmente deletar a informação ?")

            if (validarConfirmacaoUsuario) {

                fetch(`http://localhost:8082/series/${id}`,
                    {
                        method: "DELETE",
                        headers: {
                            "Content-type": "application/json"
                        }
                    }
                ).then((retorno) => retorno.json())
            } else {
                alert("A série será mantida!")
            }
        })

        tr.appendChild(tdNomeSerie)
        tr.appendChild(tdNumTemp)
        tr.appendChild(tdAnoLancamento)
        tr.appendChild(tdProdutora)
        tr.appendChild(div)
        div.appendChild(tdEdit)
        div.appendChild(tdDelete)

        listSeries.appendChild(tr)
    });
}

getSeries();